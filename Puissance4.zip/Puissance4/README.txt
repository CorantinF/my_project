Groupe: Zaouak Abdelkader, Fran�ois Corantin, Issa Razan

Sujet: Puissance 4

Semaine du 29 mars 2019: 



- Choix du trin�me et choix du sujet

- Nous avons fini la parti repr�sentation du plateau de jeu, initialisation et affichage lors de la s�ance de tp
- Nous avons ensuite fait les 4 fonctions qui permettent de jouer un coup mais nous avons quelques int�rrogation sur certain points afin de savoir si nos fonctions sont valides
- Nous avons rediger les docstrings ainsi que les doctest de toutes les fonctions �tablis auparavant

Semaine du 5 avril 2019:

- Nous avons r�alis� la fonction play qui nous permet de jouer meme sans l'affichage graphique,pour cela nous avons du r�aliser une fonction remplie pour arreter le jeu si la grille est remplie
- Nous avons regard� le code de render_connect afin de comprendre comment fonctionnait l'interface graphique
- Nous avons ecris une proc�dure dans render_connect pour jouer au jeu avec l'interface graphique, � l'aide du code de play et de l'initiaisation avec une grille classique ( 6 lignes, 7 colonnes)
- On constate que le jeu marche il suffit d'ecrire a chaque tour la colonne ou on le veut jouer jusqu'a se que la grille soit remplie
- Apr�s la s�ance de tp nous avons tap� les docstring et doctest des fonctions r�alis� pendant le tp
- Il nous faut maintenant faire la fonction qui verifie quand un joueur a gagner ou non

Semaine du 26 avril 2019:

-Nous avons fini la parti joueur en code il reste des am�liorations a founir au code au niveau des excpetions et de la documentations
-Nous cherchons comment int�grer la fonction is_win dans play pour que le jeu s'arrete lorsqu'un joueur a gagn�
-Nous avons commenc� la partie avec ia, actuelement l'ia peut jouer al�atoirement si il n'y auccun coup gagnant sinon il jouera a cet endroit

Semaine du 02 avril 2019:

-Nous avons complet� toute les docs
-Nous avons r�alis� les fonctions score
-Nous avons r�alis� un puissance 5 jouable entre joueur et toute les commandes pour jouer avec ia ou non