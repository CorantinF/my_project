#Groupe: Helle - Francois - Taleb-Ahmed
#Sujet: Nonogram
#Date: 21/03

import tk_nonogram

cat={
 "rows": "1,1;3;5;4;5",
 "cols": "3;3;5;4;3,1"
 }

foot={
    "rows":"3;5;3,1;2,1;3,3,4;2,2,7;6,1,1;4,2,2;1,1;3,1;6;2,7;6,3,1;1,2,2,1,1;4,1,1,3;4,2,2;3,3,1;3,3;3;2,1",
    "cols":"2;1,2;2,3;2,3;3,1,1;2,1,1;1,1,1,2,2;1,1,3,1,3;2,6,4;3,3,9,1;5,3,2;3,1,2,2;5,3,2;3,1,2,2;2,1,7;3,3,2;2,4;2,1,2;2,2,1;2,2;1;1"
    }

canard={
    "rows":"4;6;6,3;8;7;6;5;5;4;5;6;5;6;7,10;20,1;15,5;18,4;19,1,1;19,1;7,9,2,1;7,7,4,1;8,10,2;8,7,3;9,3;12,2",
    "cols":"1;1;1,7;3,10;5,13;6,15;2,21;25;24;9,5,5;5,6,4;8,3;9,2;9,2;10,1;10,1;10,1;2,7,1;2,4,2,1;2,3,3;3,2,3,1;3,3,2;3,2,2;2,1,3;4,4"
    }

def tableau(dico):
    """
        Fait un tableau à partir d'un dictionnaire
        :param dico: (dict)   le dictionnaire à mettre sous forme de tableau
        :return: (list)
        CU: Le dictionnaire doit être conforme à la norme que l'on a établi
        Exemples :
        >>> tableau(cat)
        [[['1', '1'], ['3'], ['5'], ['4'], ['5']], [['3'], ['3'], ['5'], ['4'], ['3', '1']]]
    """
    l1=list()
    l2=list()
    d1=dico["rows"].split(';')
    
    l3=list()
    l4=list()
    d2=dico["cols"].split(';')
    
    for e in d1 :
        l1+=[e]
    for e in l1 :
        l2+=[e.split(',')]
        
    for e in d2 :
        l3+=[e]
    for e in l3 :
        l4+=[e.split(',')]
    return [l2, l4]

def ColsWidth_RowsHeight (dico):
    """
        Compte le nombre de colonne et de rangé et les renvoies
        :param dico:  le dictionnaire à mettre sous forme de tableau
        :return: (list)
        CU: Le dictionnaire doit être conforme à la norme que l'on a établi
        Exemples :
        >>> ColsWidth_RowsHeight (cat)
        [4, 4]
    """
    l=list()
    x=0
    y=0
    for e in dico["cols"] :
        if e == ';' :
            x+=1
    
    for i in dico["rows"] :
        if i == ';' :
            y+=1
    l=[x]+[y]
    return l
 
def ColsHeigth_RowsWidth(dico) :
    """
        renvoie la hauteur des colonnes et la largeur des rangées
        :param dico:  le dictionnaire à mettre sous forme de tableau
        :return: (list)
        CU: Le dictionnaire doit être conforme à la norme que l'on a établi
        Exemples :
        >>> ColsHeigth_RowsWidth(cat)
        [2, 2]
    """
    l=list()
    x=0
    y=0
    list_dico=tableau(dico)
    for e in list_dico[0]:
        if len(e) > x :
            x = len(e)
    for i in list_dico[1]:
        if len(i) > y :
            y = len(i)
    l=[x]+[y]
    return l



if __name__ == "__main__":
     import doctest
     doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS,
                             verbose=True)