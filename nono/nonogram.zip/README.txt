﻿Groupe: Taleb-Ahmed Hacène, François Corantin, Helle Thitouane


Sujet: Nonogram


 

Semaine du 12 mars 2018: 



- Choix du trinôme et choix du sujet

- Nous avons testé des nonograms présents sur les sites nonograms.org et hanjie-star afin de mieux
  comprendre le sujet et ses règles.

- Nous avons déterminé un format de représentation des nonograms en entrée, à l'aide d'un dictionnaire pour la colonne et un autre pour la ligne, avec différents séparateurs pour savoir si l'on change de ligne ou de case.

- Nous avons trouvé à l'aide d'un hyperlien sur le sujet du nonogram, un site proposant un nonogram en forme de canard. Nous en avons pris le code de sa forme à l'aide du code source de la page.

- Nous avons créé une fonction "tableau" qui crée un tableau avec un dictionnaire en paramètre, nous avons également essayé de faire la partie "Nonogram en cours de résolution" mais nous butons encore sur cette partie, nous ne savons pas encore vraiment comment construire cette structure de données

Semaine du 19 mars 2018:

- Etude du fichier tk_nonogram.py
- Nous avont étudier puis dicuter a propos des premieres fonctions afin de mieux comprendre leurs fonctionements, car la doc est absente, pour l'appliquer a notre projet
- Developement deux nouvelles fonctions qui a pour but de compter les colonnes ainsi que leurs dimensions.
- Apres une hesitation nous estimons que la fonction faite la semaine derniere n'a besoin d'aucun changement pour faciliterl'utilisiation de la derniere.